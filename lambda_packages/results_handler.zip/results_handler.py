import json
import os
import boto3
import logging
import csv
from io import StringIO
from typing import List, Dict, Any
from dataclasses import dataclass
from datetime import datetime

# Configure logger
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# AWS clients
apigateway_management = boto3.client('apigatewaymanagementapi',
                                     endpoint_url=f"https://{os.environ.get('WEBSOCKET_API_ENDPOINT')}")


@dataclass
class UnifiedOffer:
    """Unified offer structure for all providers"""
    provider_name: str
    product_id: str
    speed_mbps: int
    monthly_cost_cents: int
    after_two_years_cost_cents: int
    contract_duration_months: int
    connection_type: str
    installation_service: bool
    tv_included: bool
    max_age: int
    voucher_type: str
    voucher_value: int


def parse_byteme_csv(csv_data: str) -> List[UnifiedOffer]:
    """Parse ByteMe CSV response and deduplicate"""
    offers = []
    seen_products = set()  # For deduplication

    try:
        # ByteMe CSV format:
        # productId,providerName,speed,monthlyCostInCent,afterTwoYearsMonthlyCost,durationInMonths,connectionType,installationService,tv,limitFrom,maxAge,voucherType,voucherValue

        csv_reader = csv.DictReader(StringIO(csv_data))

        for row in csv_reader:
            product_id = row.get('productId', '')

            # Deduplicate - ByteMe sends duplicates
            if product_id in seen_products:
                logger.info(f"Skipping duplicate product: {product_id}")
                continue
            seen_products.add(product_id)

            # Parse and validate data
            try:
                offer = UnifiedOffer(
                    provider_name=row.get('providerName', 'Unknown'),
                    product_id=product_id,
                    speed_mbps=int(row.get('speed', 0)),
                    monthly_cost_cents=int(row.get('monthlyCostInCent', 0)),
                    after_two_years_cost_cents=int(row.get('afterTwoYearsMonthlyCost', 0)),
                    contract_duration_months=int(row.get('durationInMonths', 0)),
                    connection_type=row.get('connectionType', 'Unknown'),
                    installation_service=row.get('installationService', '').lower() == 'true',
                    tv_included=row.get('tv', '').lower() == 'true',
                    max_age=int(row.get('maxAge', 0)),
                    voucher_type=row.get('voucherType', ''),
                    voucher_value=int(row.get('voucherValue', 0))
                )
                offers.append(offer)

            except (ValueError, TypeError) as e:
                logger.warning(f"Failed to parse row {row}: {e}")
                continue

    except Exception as e:
        logger.error(f"Failed to parse CSV: {e}")
        return []

    logger.info(f"Parsed {len(offers)} unique offers from ByteMe")
    return offers


def send_to_websocket(connection_id: str, message: Dict[str, Any]) -> bool:
    """Send message to WebSocket client"""
    try:
        apigateway_management.post_to_connection(
            ConnectionId=connection_id,
            Data=json.dumps(message).encode('utf-8')
        )
        logger.info(f"Message sent to WebSocket {connection_id}")
        return True
    except Exception as e:
        logger.error(f"Failed to send WebSocket message to {connection_id}: {e}")
        return False


def lambda_handler(event, context):
    """Process results from Step Functions"""
    logger.info("Results Handler started")
    logger.info(f"Event: {json.dumps(event)}")

    for record in event.get('Records', []):
        try:
            # Parse SQS message
            message_body = json.loads(record.get('body', '{}'))
            logger.info(f"Processing result for request: {message_body.get('request_id')}")

            request_id = message_body.get('request_id')
            connection_id = message_body.get('connection_id')
            provider_name = message_body.get('provider_name')
            status = message_body.get('status')

            if status == 'success':
                # Parse provider response
                raw_response = message_body.get('raw_response', '')

                if provider_name == 'byteme':
                    offers = parse_byteme_csv(raw_response)

                    # Send results to WebSocket
                    websocket_message = {
                        'type': 'PROVIDER_RESULT',
                        'request_id': request_id,
                        'provider': provider_name,
                        'status': 'success',
                        'offers': [
                            {
                                'provider_name': offer.provider_name,
                                'product_id': offer.product_id,
                                'speed_mbps': offer.speed_mbps,
                                'monthly_cost_euros': offer.monthly_cost_cents / 100,
                                'after_two_years_cost_euros': offer.after_two_years_cost_cents / 100,
                                'contract_duration_months': offer.contract_duration_months,
                                'connection_type': offer.connection_type,
                                'installation_service': offer.installation_service,
                                'tv_included': offer.tv_included,
                                'voucher_type': offer.voucher_type,
                                'voucher_value_euros': offer.voucher_value / 100
                            }
                            for offer in offers
                        ],
                        'total_offers': len(offers),
                        'timestamp': datetime.utcnow().isoformat()
                    }

                else:
                    logger.warning(f"Unknown provider: {provider_name}")
                    continue

            else:
                # Handle failure
                websocket_message = {
                    'type': 'PROVIDER_RESULT',
                    'request_id': request_id,
                    'provider': provider_name,
                    'status': 'failed',
                    'error': message_body.get('error_details', 'Unknown error'),
                    'offers': [],
                    'timestamp': datetime.utcnow().isoformat()
                }

            # Send to WebSocket
            send_to_websocket(connection_id, websocket_message)

        except Exception as e:
            logger.error(f"Error processing record: {e}")
            continue

    return {"statusCode": 200, "body": "Results processed"}